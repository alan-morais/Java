# ###################################################### #
# Data de cria��o   - pgm : 05/04/2018                   #
# Data de altera��o - pgm	: 13/04/2018                   # 
# Base de dados		        : Carteira Brasil              #
# Autor			              : First Decision               #
# Programa			          : Analise_Carteira_Brasil -    #      
#                           Correlacao.R                 #
# Banco de Dados          : Servidor da Caixa - FUGDB001 #
# Tabela                  : IFGTFR001_DEBITO             #
# Data da execu��o        : 10/04/2018                   # 
# ###################################################### # 

# Bibliotecas utilizadas #
library(ggplot2)
library(RODBC)
library(tidyr)
library(MASS)
library(dplyr)
library(ggpubr)

# Par�metro de ambiente
# Ambiente - Externo/Interno
# Ambiente <- "Externo"
Ambiente <- "Interno"

if (Ambiente == "Externo") {
  
  # Acessando o banco de dados SQL Server - Desenvolvimento - Via VPN #
  nserver		  <- "172.16.141.87" 
  ndatabase 	<- "FUGDB001"
  username 	  <- "SPCFUGD01" 
  password 	  <- "SPCFUGD01" 
  conexao 	  <- paste("driver={ODBC Driver 13 for SQL Server};server=",nserver,";database=",ndatabase,";uid=",username,";pwd=",password, sep = '')
  conn 		    <- odbcDriverConnect(conexao)
  
} else {
  
  if (Ambiente == "Interno") {
    
    # Acessando o banco de dados SQL Server - Desenvolvimento - Via Rede Caixa - RG #
    nserver		  <- "10.116.92.87" 
    ndatabase 	<- "FUGDB001"
    username 	  <- "SPCFUGD01" 
    password 	  <- "SPCFUGD01" 
    conexao 	  <- paste("driver={ODBC Driver 11 for SQL Server};server=",nserver,";database=",ndatabase,";uid=",username,";pwd=",password, sep = '')
    conn 		    <- odbcDriverConnect(conexao)
  }
}

# Execu��o e armazenamento da query #
psql1 <- "select a.NU_IDNTR_DEBITO, a.NU_TP_NATUREZA_DEBITO, a.NU_IDNTR_SITUACAO_DEBITO, a.NU_CNAE, a.NU_IDNTR_LOCALIDADE, "

# Toda a base D�bito do desenvolvimento #
# psql2 <- "a.NU_TP_RECUPERACAO, a.NU_IDNTR_GIFUG, a.VR_DEB_ATUAL, a.VR_RECUPERADO from IFGTFR001_DEBITO a order by a.NU_IDNTR_DEBITO;"

# NU_CNAE <> -1 e -7 #
psql2 <- "a.NU_TP_RECUPERACAO, a.NU_IDNTR_GIFUG, a.VR_DEB_ATUAL, a.VR_RECUPERADO from IFGTFR001_DEBITO a where (a.NU_CNAE <> -1 AND a.NU_CNAE <> -7) order by a.NU_IDNTR_DEBITO;"

sql1 <- sqlQuery(conn,paste(psql1,psql2))

# Gr�fico dos dados #
# plot(sql1)

# Verifica��o de NA - Not Available (Dados Faltantes)
# dadfalt <- sql1[is.na(sql1$Variavel),]
# ou
# Na pr�pria fun��o de correla��o
# cor(sql1, method = "pearson", use = "complete.obs")

# Sum�rio de estat�sticas descritivas dos dados do D�bito #
# Vari�vel - posi��o 2 at� 8 #
summary(sql1[2:8])

# Matriz de Correla��o
# Vari�vel - posi��o 2 at� 8
(mc <- cor(sql1[2:8]))

# Visualiza��o da Matriz de Correla��o
symnum(mc)

#                                                                 #
# Estudo pontual das vari�veis NU_IDNTR_SITUACAO_DEBITO e         #
# NU_TP_RECUPERACAO (2.melhor correla��o encontrada).             #
# A correla��o entre elas � de 0.49835743 na massa de dados de    #
# do dia 10/04/2018.                                              #
#                                                                 # 
# NOTA IMPORTANTE: Embora matematicamente exista essa pequena     #
# correla��o, n�o necessariamente possa implicar causalidade.     #
#                                                                 #

# Visualiza��o dos dados das vari�veis NU_IDNTR_SITUACAO_DEBITO e #
# NU_TP_RECUPERACAO                                               #
ggscatter(sql1, x = "NU_IDNTR_SITUACAO_DEBITO", y = "NU_TP_RECUPERACAO",
          add = "reg.line", conf.int = TRUE,
          cor.coef = TRUE , cor.method = "pearson",
          xlab = "Situa��o do D�bito", ylab = "Tipo da Recupera��o") 

# Verifica��o se os dados seguem uma distribui��o normal.
# Uso do teste Shapiro-Wilk (fun��o: shapiro.test()).
# Nota: Este teste poder� ser importante, pelo motivo que 
# caso a distribui��o n�o seja normal, podemos utilizar o m�todo 
# Kendall ou spearmon da fun��o correla��o. Para determina��o da 
# normalidade, observa-se o p-value (valores maiores que 0,05 por
# exemplo).
shapiro.test(sql1$NU_IDNTR_SITUACAO_DEBITO)
shapiro.test(sql1$NU_TP_RECUPERACAO)

# Visualiza��o da normalidade dos campos 
# NU_IDNTR_SITUACAO_DEBITO e NU_TP_RECUPERACAO
ggqqplot(sql1$NU_IDNTR_SITUACAO_DEBITO)
ggqqplot(sql1$NU_TP_RECUPERACAO)


## An�lise e C�digo em estudo
## Objetivo: C�lculo de correla��o por grupo (fun��o aes())
# ggscatter(sql1, x = sql1$NU_IDNTR_SITUACAO_DEBITO, y = sql1$NU_TP_RECUPERACAO,
#          add = "reg.line",
#          conf.int = TRUE,
#          color = sql1$NU_CNAE, pallete = "jco",
#          shape = sql1$NU_CNAE
#          )+
#  stat_cor(aes(color = sql1$NU_CNAE), label.x = 3 )

















